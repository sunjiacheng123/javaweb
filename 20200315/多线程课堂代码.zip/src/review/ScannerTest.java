package review;

import org.junit.Test;

import java.util.Scanner;

public class ScannerTest {

    public static void main(String[] args) {
        // scanner.hasNext,next, hasNextLine, nextLine, hasNextInt, nextInt...全部阻塞方法
        Scanner sc = new Scanner(System.in);
        while (sc.hasNext()){//空格、换行符
            System.out.println(sc.next());
        }

//        Scanner sc = new Scanner(System.in);
//        while(sc.hasNextLine()){
//            System.out.println(sc.nextLine());
//        }

        // 第一行是一个数字n，第二行有n个数字，以空格间隔
        // 例如：第一行4，第二行2 4 1 3
//        Scanner sc = new Scanner(System.in);
//        int count = sc.nextInt();
//        for(int i=0; i<count; i++){
//            int num = sc.nextInt();
//        }
    }

}
