package lesson4;

public class VolatileTest2 {

    private volatile static int SUM;
    public static void main(String[] args) {
        for(int i=0; i<20; i++){
            new Thread(new Runnable() {
                @Override
                public void run() {
                    for(int j=0; j<10000; j++){
//                        if(SUM<100000) {
//                            synchronized (VolatileTest2.class) {
//                                SUM++;
////                            else
////                                break;
//                            }
//                        }
                        // 问题：怎么样能保证线程安全，又能够最大的提高效率
                        synchronized (VolatileTest2.class) {
                            if(SUM<100000)
                                SUM++;
//                            else
//                                break;
                        }
                    }
                }
            }).start();
        }
        while(Thread.activeCount() > 1){//debug运行
            Thread.yield();
        }
        System.out.println(SUM);
    }
}
